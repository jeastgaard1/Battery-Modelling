% Function that determines the terminal voltage of the volume dependant 2RC
% Thevian model.
function U_term = ECM_term_volt(t, U_RC, param)
% U_RC is desinged to be calculated through ODE45 using MATLAB.
U_RC1 = U_RC(1);
U_RC2 = U_RC(2);

I = param.I(t);

U_term = param.UCell(t) - I * param.R0(t) - U_RC1 - U_RC2;


end