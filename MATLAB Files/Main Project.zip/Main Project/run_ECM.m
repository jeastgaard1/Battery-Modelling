%##########################################################################
%
% General points
% === Electro-chemical ===============================
% Full Cell ECM: OCV + R(Si_t) + RC1(Si_t) + RC2(Si_t)
% Expansion based on GrSi anode
% ====================================================
%
% === Thermal: ===
% Irreversible Heat
% Reversible Heat
% Cooling
% =================
%
% === Mechanical: ====
% Reversible Expansion
% ====================
%
% === Parametrization =======================
% <TODO> Still need to parameratize based on
% a specific cell type that is chosen.
% ===========================================
% 
% === Structure====================================================
% run main file: "run_ECM"
% -options:         loads all set options
% -cell parameters: loads parametrization & data of considered cell
% =================================================================
%%

clear
clc

% This code allows MATLAB to find all the required files.
addpath(genpath('Models'));
addpath(genpath('Electrical'));

[options,msg] = options_ECM_VolThev; % Loads all settings

% [param] = ECM_Parameter_ECM_VolThev(options, 0, 0); % Loads cell parameter with 0 % Si
[battery_res, data_save] = structure_ECM_2RC_VolThev(options);% Loads final strucutre for results

% Setting initial values
battery_res.T.T_lowC(1,1) = options.ini.T;
battery_res.T.T_midC(1,1) = options.ini.T;
battery_res.T.T_highC(1,1) = options.ini.T;

battery_res.Aging.SoH_R(1,1)=1; %Set inital SoH values
battery_res.Aging.SoH_C(1,1)=1; %Set inital SoH values

%% ODE for Terminal Voltage
for cr = 1:length(options.cRates)
    figure; hold on;
    for w = 1:length(options.wtSi) % Loop through different Si%
        % Creating new parameters every time with different cell (wt%) and
        % C-Rates for simulation. Redundant/expensive but simple solution.        
        [param]=ECM_Parameter_ECM_VolThev(options,options.wtSi(w),options.cRates(cr));
        fprintf("Running with Si wt%% = %.2f'\n", param.anode.wtSi);
        
        % Set up ODE equation
        x0 = [0; 0];
        ode_function = @(t,x) ECM_RC_ode(t, x, param);
        %ode15s is used for stiff simulation if we want to exagerate values.
        % ode45 is used for non-stiff simulation (but slower sim time).
        [t_sim, u_sim] = ode15s(ode_function, options.time_span, x0); 
        % Compute terminal voltage
        V_sim = zeros(size(t_sim));
        
        for k = 1:numel(t_sim)
            V_sim(k) = ECM_term_volt(t_sim(k), u_sim(k,:).', param);
            % This Battery_Model is where all models will be called each loop.
            % [battery_res,msg,options] = Battery_Model_ECM_VolThev(battery_res,param,msg,options,const); %Cell ECM Model
            [battery_res] = ThermalVSSi_Model(battery_res,param,options,k,w,cr);
            
            % After every model generation, data will need to be saved so
            % that it can be plotted later.
            [data_save] = SaveData(battery_res,data_save,options,k,w,cr); %Save Data
            battery_res.time(1,1) = k;
        end
        % running the Current_Distribution_Model only once but over all time steps
        % Take entire t_sim array as input
        % Loop internally through all time points
        % Return complete results for all times
        current_dist_time = Current_Distribution_Model(param, options, t_sim);
        % Store results for this w, cr combination
        data_save.current_dist.I_Si(:, w, cr) = current_dist_time.I_Si;
        data_save.current_dist.I_G(:, w, cr) = current_dist_time.I_G;
        data_save.current_dist.j_Si(:, w, cr) = current_dist_time.j_Si;
        data_save.current_dist.j_G(:, w, cr) = current_dist_time.j_G;
        data_save.current_dist.eta(:, w, cr) = current_dist_time.eta;
        data_save.current_dist.SOC(:, w, cr) = current_dist_time.SOC;
        data_save.current_dist.frac_Si(:, w, cr) = current_dist_time.frac_Si;
        data_save.current_dist.frac_G(:, w, cr) = current_dist_time.frac_G;

        %% Volumetric capacity model - ONLY for first C-rate
        if cr == 1
            fprintf('  → Calculating volumetric capacity analysis...\n');
            vol_cap = Volumetric_Capacity_Model(param, options);
            data_save.vol_cap{w} = vol_cap;  % Store only once per Si wt%
            fprintf('  ✓ Volumetric capacity analysis complete\n');
        end

        % Plot
        plot(t_sim, V_sim, 'LineWidth', 2, ...
             'DisplayName', sprintf('Si wt%% = %.2f', options.wtSi(w)));
    
    end
    xlabel('Time [min]');
    ylabel('Terminal Voltage [V]');
    title(sprintf('GrSi ECM Simulation with differnt Si.-wt%% ( C-Rate of %.1f)',options.cRates(cr)));
    grid on;                         
    legend('show');
end

%% ═══════════════════════════════════════════════════════════════════════
%% PLOT CURRENT DISTRIBUTION FOR ALL C-RATES (PRAVEEN)
%% ═══════════════════════════════════════════════════════════════════════
for cr = 1:length(options.cRates)
    figure('Position', [100 + cr*50, 100 + cr*50, 1400, 700]);
    set(gcf, 'Color', 'w');
    
    % Select 4 time snapshots
    t_vec = data_save.time(1:param.time_mid - 1, 1);
    time_snapshots = round(linspace(1, length(t_vec), 4));
    
    for t_idx = 1:4
        subplot(2, 2, t_idx);
        
        I_Si_snapshot = data_save.current_dist.I_Si(time_snapshots(t_idx), :, cr) * 1000;
        I_G_snapshot = data_save.current_dist.I_G(time_snapshots(t_idx), :, cr) * 1000;
        
        b = bar([I_G_snapshot; I_Si_snapshot]', 'grouped');
        b(1).FaceColor = [0.47 0.67 0.19];  % Graphite
        b(2).FaceColor = [0.85 0.33 0.10];  % Silicon
        
        set(gca, 'XTickLabel', arrayfun(@(x) sprintf('%.0f%%', x*100), options.wtSi, 'UniformOutput', false));
        xlabel('Si Content [wt-%]', 'FontSize', 11, 'FontWeight', 'bold');
        ylabel('Current [mA]', 'FontSize', 11, 'FontWeight', 'bold');
        title(sprintf('Time = %.1f min', t_vec(time_snapshots(t_idx))), ...
              'FontSize', 12, 'FontWeight', 'bold');
        legend('Graphite', 'Silicon', 'Location', 'best');
        grid on;
    end
    
    sgtitle(sprintf('Current Distribution Snapshots at C-Rate %.1f', options.cRates(cr)), ...
            'FontSize', 16, 'FontWeight', 'bold');
end

%% ═══════════════════════════════════════════════════════════════════════
%% PLOT VOLUMETRIC CAPACITY CASE STUDIES (PRAVEEN - Otero et al. 2018 Style)
%% ═══════════════════════════════════════════════════════════════════════
fprintf('\n');
fprintf('═══════════════════════════════════════════════════════════════\n');
fprintf('  PLOTTING VOLUMETRIC CAPACITY CASE STUDIES\n');
fprintf('═══════════════════════════════════════════════════════════════\n\n');

% Extract data for FIRST C-rate only (typically done in papers)
cr = 1;  % Use first C-rate for case study plots

% Initialize arrays
wtSi_array = zeros(length(options.wtSi), 1);
G_A_array = zeros(length(options.wtSi), 1);
V_A_case1 = zeros(length(options.wtSi), 1);
P_A_req_case1 = zeros(length(options.wtSi), 1);

% Extract data from data_save for Case 1
for w = 1:length(options.wtSi)
    vol_cap = data_save.vol_cap{w};
    wtSi_array(w) = vol_cap.wtSi;
    G_A_array(w) = vol_cap.G_A;
    
    % Case 1
    V_A_case1(w) = vol_cap.case1.V_A;
    P_A_req_case1(w) = vol_cap.case1.P_A_required;
end

%% ═══════════════════════════════════════════════════════════════════════
%% FIGURE 1: CASE STUDY 1 - Zero Expansion (E=0 & P_ALi=0)
%% ═══════════════════════════════════════════════════════════════════════
figure('Position', [100, 100, 1200, 700]);
set(gcf, 'Color', 'w');

% Left Y-axis: Volumetric and Gravimetric Capacity
yyaxis left;
hold on; grid on; box on;

% Plot Volumetric Capacity (Red)
plot(wtSi_array, V_A_case1, '-', 'LineWidth', 3, ...
     'Color', [0.85 0.33 0.10], 'DisplayName', 'V_A (Si/Graphite)');

% Plot Gravimetric Capacity (Green)
plot(wtSi_array, G_A_array, '-', 'LineWidth', 3, ...
     'Color', [0.47 0.67 0.19], 'DisplayName', 'G_A (Si/Graphite)');

ylabel('Specific Capacity V_A in mAh/cm^3 & G_A in mAh/g', ...
       'FontSize', 12, 'FontWeight', 'bold');
ylim([0, 3500]);
set(gca, 'YColor', 'k');

% Right Y-axis: Initial Porosity
yyaxis right;
hold on;

% Plot Required Porosity (Blue)
plot(wtSi_array, P_A_req_case1, '-', 'LineWidth', 3, ...
     'Color', [0.00 0.45 0.74], 'DisplayName', 'P_A (Si/Graphite)');

% Mark P_A = 30% intersection (black square)
P_A_target = 30;
idx_30 = find(P_A_req_case1 >= P_A_target, 1, 'first');
if ~isempty(idx_30)
    plot(wtSi_array(idx_30), P_A_target, 'ks', ...
         'MarkerSize', 12, 'MarkerFaceColor', 'k', 'DisplayName', 'data1');
    
    % Vertical dashed line at this Si%
    xline(wtSi_array(idx_30), '--k', 'LineWidth', 1.5);
    
    % Horizontal dashed line at P_A = 30%
    yline(P_A_target, '--k', 'LineWidth', 1.5);
end

ylabel('Initial electrode porosity P_A (vol-%)', ...
       'FontSize', 12, 'FontWeight', 'bold');
ylim([0, 100]);
set(gca, 'YColor', [0.00 0.45 0.74]);

% X-axis
xlabel('Silicon w_{Si} amount (wt-%)', 'FontSize', 12, 'FontWeight', 'bold');
xlim([0, 100]);

% Title
title('Case-Study 1: Zero Expansion (E=0 & P_{ALi}=0)', ...
      'FontSize', 14, 'FontWeight', 'bold');

% Legend
legend('Location', 'northwest', 'FontSize', 11);
set(gca, 'FontSize', 11, 'LineWidth', 1.5);

fprintf('✓ Case Study 1 plot created\n');

%% ═══════════════════════════════════════════════════════════════════════
%% FIGURE 2: CASE STUDY 2 - Constant Porosity (P_A = P_ALi)
%% ═══════════════════════════════════════════════════════════════════════

% Define porosity levels to plot
porosity_levels = [0, 10, 20, 30, 40];  % vol-%
n_porosity = length(porosity_levels);

% Colors for different porosities (from blue to green)
colors_porosity = [
    0.00 0.45 0.74;   % Blue - 0%
    0.85 0.33 0.10;   % Red - 10%
    0.93 0.69 0.13;   % Orange - 20%
    0.49 0.18 0.56;   % Purple - 30%
    0.47 0.67 0.19;   % Green - 40%
];

% Extract V_A for each porosity level (already calculated in model!)
V_A_case2_all = zeros(length(options.wtSi), n_porosity);
E_case2 = zeros(length(options.wtSi), 1);

for w = 1:length(options.wtSi)
    vol_cap = data_save.vol_cap{w};
    
    % Get expansion
    E_case2(w) = vol_cap.case2.E;
    
    % Get pre-calculated V_A for all porosities
    V_A_case2_all(w, :) = vol_cap.case2.V_A_array;
end

figure('Position', [150, 150, 1400, 700]);
set(gcf, 'Color', 'w');

% Left Y-axis: Volumetric Capacity
yyaxis left;
hold on; grid on; box on;

% Plot V_A for each porosity level
for p = 1:n_porosity
    plot(wtSi_array, V_A_case2_all(:, p), '-', 'LineWidth', 3, ...
         'Color', colors_porosity(p, :), ...
         'DisplayName', sprintf('Porosity %d%%', porosity_levels(p)));
end

ylabel('Volumetric capacity V_A (mAh/cm^3)', ...
       'FontSize', 12, 'FontWeight', 'bold');
ylim([0, 2400]);
set(gca, 'YColor', 'k');

% Right Y-axis: Expansion Tolerance
yyaxis right;
hold on;

% Plot Expansion (thick blue line)
plot(wtSi_array, E_case2, '-', 'LineWidth', 4, ...
     'Color', [0.00 0.45 0.74], 'DisplayName', 'Expansion tolerance factor');

ylabel('Expansion Tolerance E (vol-%)', ...
       'FontSize', 12, 'FontWeight', 'bold');
ylim([0, 250]);
set(gca, 'YColor', [0.00 0.45 0.74]);

% X-axis
xlabel('Silicon w_{Si} amount (wt-%)', 'FontSize', 12, 'FontWeight', 'bold');
xlim([0, 100]);

% Title
title('Case-Study 2: Constant Porosity (P_A = P_{ALi})', ...
      'FontSize', 14, 'FontWeight', 'bold');

% Legend
legend('Location', 'northwest', 'FontSize', 11);
set(gca, 'FontSize', 11, 'LineWidth', 1.5);

fprintf('✓ Case Study 2 plot created\n');
fprintf('✓ All volumetric capacity case study plots complete!\n\n');

%% Plot Save_Data
% Same as above, we need to plot different wt% for each C-Rate.
for cr = 1:length(options.cRates)

    figure; hold on; grid on;

    % Time vector for discharge/charge for plotting
    t_sim_DCH = data_save.time(1:param.time_mid - 1,1);
    t_sim_CH = data_save.time(param.time_mid : options.data.steps,1);

    % Colors for wt% curves
    cmap = [
        0.85 0.33 0.10;   % orange
        0.93 0.69 0.13;   % yellow-gold
        0.49 0.18 0.56;   % purple
        0.47 0.67 0.19;   % olive green
        0.64 0.08 0.18    % dark red
    ];

    % Temperature axis (left)
    yyaxis left;
    subplot(1,2,1);
    hold on;

    for w = 1:length(options.wtSi)
        plot(t_sim_DCH, ...
             data_save.T.(options.Save.T{cr})(1:param.time_mid - 1,w), ...
             'Color', cmap(w,:), ...
             'LineWidth', 1.5, ...
             'DisplayName', sprintf('Si wt%% = %.2f', options.wtSi(w)));        
    end

    % SoC axis (right)
    yyaxis right

    plot(t_sim_DCH, data_save.SoC(1 : param.time_mid - 1,1), ...
         'Color', [0 0.45 0.70], ...   % strong blue
         'LineWidth', 2, ...
         'DisplayName', 'SoC');
    xlim([min(t_sim_DCH) max(t_sim_DCH)])
    ylabel('State of Charge [-]');
    ylabel('Temperature [K]');
    xlabel('Time [min]');
    title(sprintf('Thermal & SoC Evolution at %.1fC Discharge', options.cRates(cr)));
    legend('Location','best');

    % Temperature axis (left)
    yyaxis left;
    subplot(1,2,2);
    hold on;
    for w = 1:length(options.wtSi)
        plot(t_sim_CH, ...
             data_save.T.(options.Save.T{cr})(param.time_mid : options.data.steps,w), ...
             'Color', cmap(w,:), ...
             'LineWidth', 1.5, ...
             'DisplayName', sprintf('Si wt%% = %.2f', options.wtSi(w)));
    end
    ylabel('Temperature [K]')
   

    % SoC axis (right)
    yyaxis right
    plot(t_sim_CH, data_save.SoC(param.time_mid : options.data.steps,1), ...
         'Color', [0 0.45 0.70], ...   % strong blue
         'LineWidth', 2, ...
         'DisplayName', 'SoC');
    xlim([min(t_sim_CH) max(t_sim_CH)])
    ylabel('State of Charge [-]');
    ylim([0 1]);
    xlabel('Time [min]');
    title(sprintf('Thermal & SoC Evolution at %.1fC Charge', options.cRates(cr)));
    legend('Location','best');
end